export const environment = {
    api: "https://backend.min4max.net/api",
    appId: 2
}
